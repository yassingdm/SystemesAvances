#ifndef EXTERN_TYPES_H
#define EXTERN_TYPES_H

#include <api_lopht.h>

#define True 1

#endif
