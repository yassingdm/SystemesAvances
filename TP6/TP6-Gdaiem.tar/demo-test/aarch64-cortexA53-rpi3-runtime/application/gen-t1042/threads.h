void global_init(void);
void mif_entry_point_cpu0(void);
void mif_entry_point_cpu1(void);
void mif_entry_point_cpu2(void);

