#include "variables.h"

int x, y, u;
int z = 123;
