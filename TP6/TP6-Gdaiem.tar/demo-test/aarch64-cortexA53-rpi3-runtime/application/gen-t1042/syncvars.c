#include "syncvars.h"

int64_t loc_pc_0 = -1;
int64_t loc_pc_1 = -1;
