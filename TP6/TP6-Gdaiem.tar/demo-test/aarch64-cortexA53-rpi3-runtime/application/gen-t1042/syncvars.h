#ifndef _SYNCVARS_H
#define _SYNCVARS_H

#include <stdint.h>

extern int64_t loc_pc_0;
extern int64_t loc_pc_1;

#endif
