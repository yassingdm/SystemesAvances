/* variable definition header */
#include "extern-types.h"
extern int	y  ;
extern int	x  ;
extern int	z_1  ;
