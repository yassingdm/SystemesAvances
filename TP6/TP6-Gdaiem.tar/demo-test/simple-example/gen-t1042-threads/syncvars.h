#include <api_lopht.h>

extern LOPHT_MIF_CNT_TYPE mif_cnt ; 
extern LOPHT_PC_TYPE loc_pc_0; 
extern LOPHT_PC_TYPE loc_pc_1; 
extern LOPHT_PC_TYPE loc_pc_2; 

