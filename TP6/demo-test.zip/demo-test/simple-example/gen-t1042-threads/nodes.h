#include "extern-types.h"

extern void g_step(		int gen1, 
		int*gen2);
extern void f_step(		int*gen3);
extern void h_step(		int gen4, 
		int gen5, 
		int*gen6);

