#include "syncvars.h"

SECTION_ATTR(".data.cpu0.entry")
LOPHT_MIF_CNT_TYPE mif_cnt = 0 ;
SECTION_ATTR(".data.cpu0.entry")
LOPHT_PC_TYPE loc_pc_0 = 10000 ;
SECTION_ATTR(".data.cpu1.entry")
LOPHT_PC_TYPE loc_pc_1 = 10000 ;
SECTION_ATTR(".data.cpu2.entry")
LOPHT_PC_TYPE loc_pc_2 = 10000 ;
