#!/bin/bash

rm -f *.txt
rm -rf cp*
rm -f  debug.log *.epci normalized.gc try.gc try.mls try-renamed.gc
