#ifndef CRC16_H
#define CRC16_H

#include <stdint.h>

uint16_t crc16(const uint8_t *data, uint32_t size) ;

#endif
