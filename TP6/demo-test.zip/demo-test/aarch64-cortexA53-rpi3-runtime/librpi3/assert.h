#ifndef ASSERT_H
#define ASSERT_H

#define static_assert _Static_assert

#endif
