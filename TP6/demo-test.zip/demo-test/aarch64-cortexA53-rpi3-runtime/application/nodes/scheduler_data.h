/* --- Generated the 18/11/2025 at 17:8 --- */
/* --- heptagon compiler, version 1.05.00 (compiled tue. sep. 23 21:17:51 CET 2025) --- */
/* --- Command line: /home/yassi/.opam/4.14.1/bin/heptc -target c scheduler_data.ept externc.epi scheduler.ept --- */

#ifndef SCHEDULER_DATA_H
#define SCHEDULER_DATA_H

#include "scheduler_data_types.h"
#endif // SCHEDULER_DATA_H
