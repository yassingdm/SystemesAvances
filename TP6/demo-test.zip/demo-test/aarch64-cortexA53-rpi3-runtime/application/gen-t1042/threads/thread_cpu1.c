#include <nodes.h>
#include <variables.h>
#include <syncvars.h>
#include <librpi3/arm-config.h>

#define WAIT_END(var) while(api_ldar(&var) != -1)

#define N_TASKS  Scheduler__ntasks

extern bool task_end[N_TASKS];
extern Scheduler__scheduler_mem g_sched_mem;
extern Scheduler__scheduler_out g_sched_out;

static void execute_task_cpu(int cpu_id, int task_id)
{
    if (task_id >= 0 && task_id < N_TASKS) {
        printf("RPI: CPU%d executes TASK %d\n", cpu_id, task_id);
        task_end[task_id] = true;
    } else if (task_id == N_TASKS) {
        printf("RPI: CPU%d idle (no task)\n", cpu_id);
    } else {
        printf("RPI: CPU%d ERROR invalid task id %d (N_TASKS=%d)\n",
               cpu_id, task_id, N_TASKS);
    }
}


void mif_entry_point_cpu1(void)
{
    WAIT_CPU(loc_pc_0, 0);

    int t1 = g_sched_out.task_run[1];  
    execute_task_cpu(1, t1);

    UPDATE_CPU(loc_pc_1, 0);

    WAIT_END(loc_pc_0);
}
