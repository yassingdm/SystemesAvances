#include <nodes.h>
#include <variables.h>
#include <syncvars.h>
#include <librpi3/arm-config.h>
#include "scheduler.h"
#include "scheduler_data.h"

#define N_TASKS  Scheduler_data__ntasks

bool task_end[N_TASKS];
Scheduler__scheduler_mem g_sched_mem;
Scheduler__scheduler_out g_sched_out;

void global_init(void)
{
    Scheduler__scheduler_reset(&g_sched_mem);

    for (int i = 0; i < N_TASKS; i++) {
        task_end[i] = false;
    }
}

static void execute_task_cpu(int cpu_id, int task_id)
{
    if (task_id >= 0 && task_id < N_TASKS) {
        printf("RPI: CPU%d executes TASK %d\n", cpu_id, task_id);
        task_end[task_id] = true; 
    } else if (task_id == N_TASKS) {
        printf("RPI: CPU%d idle (no task)\n", cpu_id);
    } else {
        printf("RPI: CPU%d ERROR invalid task id %d (N_TASKS=%d)\n",
               cpu_id, task_id, N_TASKS);
    }
}

void mif_entry_point_cpu0(void)
{

    Scheduler__scheduler_step(task_end, &g_sched_out, &g_sched_mem);

    for (int i = 0; i < N_TASKS; i++) {
        task_end[i] = false;
    }

    UPDATE_CPU(loc_pc_0, 0);

    int t0 = g_sched_out.task_run[0];
    execute_task_cpu(0, t0);

    WAIT_CPU(loc_pc_1, 0);

    UPDATE_CPU(loc_pc_0, -1);
}
