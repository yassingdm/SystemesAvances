#ifndef _VARIABLES_H
#define _VARIABLES_H

extern int x, y, u;
extern int z;

#endif
