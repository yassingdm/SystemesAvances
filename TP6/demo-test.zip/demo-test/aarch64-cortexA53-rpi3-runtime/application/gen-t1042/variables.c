#include "variables.h"
#include "scheduler.h"
#include "scheduler_data.h"

Scheduler__scheduler_mem g_sched_mem;
Scheduler__scheduler_out g_sched_out;

int g_task_end[Scheduler_data__ntasks];
